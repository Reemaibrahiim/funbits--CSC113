
package project;

public class food extends menuitem  {
    private int calories;
private int quantity;

	
public food(String n,double p, char s,int c,int q) {
super(n,p,s);
calories=c;
quantity=q;		
}
	
public int getCalories() {
		return calories;
}

	
public void setCalories(int calories) {
		this.calories = calories;
}

public int getQuantity() {
return quantity;
}

	
public void setQuantity(int quantity) {
this.quantity = quantity;
}

public double getPrice(){
	return quantity*price;
	}

	
	@Override
public String toString() {
		return   super.toString()+ getPrice() +"]";
	}
    
}
