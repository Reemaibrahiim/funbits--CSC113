/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package project;

/**
 *
 * @author reema
 */
public class InvalidOrderID extends RuntimeException {

    /**
     * Creates a new instance of <code>InvalidOrderID</code> without detail
     * message.
     */
    public InvalidOrderID() {
        
    }

    /**
     * Constructs an instance of <code>InvalidOrderID</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public InvalidOrderID(String msg) {
        super(msg);
    }
}
