
package project;
public class drink extends menuitem {
   public drink(String name, double price, char size) {
		super(name, price, size);
	}
	

	public double getPrice(){
		if(name.equals("Juice"))
		return price=price+2;
		else if (name.equals("Pepsi"))
			return price=price+5;
	return 0;
	}
	@Override
	public String toString() {
		return  super.toString() + getPrice() + "]";
	 
    
        }}
