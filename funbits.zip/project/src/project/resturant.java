package project;

import java.io.Serializable;


public class resturant implements Serializable{
     private String name;
	   private menuitem menue [];
	   private order  OList[];
	   private int numO;
	   private int items;

	   public resturant(String name, int Maxsize,int Maxitem) {
	      this.name = name;
	      this.numO = 0;
	      this.items = 0;
	      menue =new menuitem [Maxitem];
	      OList=new order[Maxsize];
	   }
			
	   public void addItem(menuitem it) // add comp
	   {
	      if (items<menue.length)
	      {
	         if (it instanceof food)
	            menue[items++]=new food (it.getName(),it.getPrice(),it.getSize(),((food)it).getCalories(),((food)it).getQuantity());//use casting to reach subClass method
	         else if (it instanceof drink )
	            menue[items++]=new serving_tempreture (it.name,it.getPrice(),it.size,((serving_tempreture)it).isCold());
	      		
	      }
	      else 
	         System.out.println("Array is full");  
	   		
	   }

	   public boolean addOrder (order o)
	   {
	   	  
	      if (numO<OList.length && searchOrder(o.getId())==-1)
	      {
	         OList[numO++]=o;
	         System.out.println("order added succesfully");
                 return true;
	      }
	      else {
	         System.out.println("couldn't add order");
              return false;}
	   }
		  
	   public int searchOrder(int ID) {  //search method 
	      int index=-1;
	   	  
	      for (int i=0;i<numO;i++)
	         if (OList[i].getId()==ID) {
	            index=i;
	            break;
	         }
	      return index;
	   	  
	   }
		 
	   public String orderBill(int id)
	   {
	      int index=searchOrder(id);
	      if(index==-1) 
                  throw new InvalidOrderID("Id is not found");
	         return this.OList[index].printBill();
	        
	   	  
	   }
	   public void removeOrder(int ID)  //remove with shifting 
	   {
	      int index =searchOrder(ID);
	   				
	      if (index==-1)
                  throw new InvalidOrderID("Id is not found");
	      {
	         for(int i=index;i<numO-1;i++)
	            OList[i]=OList[i+1];
	      		     		
	         numO--;
	         OList[numO]=null;
	         System.out.println("deleted succesfully (:");
	      }
	   }
			
	   public String ShowMenue()
	   {   
               String str="id  |name    |size|price\n";
               str+="------------------------------\n";
	      for (int i=0;i<items;i++)
	        str+= (i+1)+menue[i].toString()+"\n";
              return str;
	   		
	   }
	      
	   public void addItemToOrder(int ID,int menuitemindex )
	   {
	      int index =searchOrder(ID);
	   				
	      if (index!=-1){
	         OList[index].addItem(menue[menuitemindex]);
	               
	      }
	      else 
	         System.out.println("No such order id "+ID);
	   
	                  
	   
	   }
           public String getName(){
           return name;}
           
           public String [] MenueItems()
           {
               String itemsN[]=new String [this.items];
               
               for (int i=0;i<items;i++){
                  itemsN[i]=this.menue[i].toString();
                  System.out.println(""+itemsN[i]+"\n");
               }
               return itemsN;
           }
           String allOrders()
           {
               String str="";
                str+="********************************\n";
               double totalsale=0;
               for (int i=0;i<numO;i++){
	         str+=OList[i].printBill()+"\n";
                 totalsale+=OList[i].TotalPrice();
               }
               str+="Total sales="+totalsale+ "\n";
               str+="********************************\n";
           return str;
           }
           
           }
