package project;
public class serving_tempreture extends drink {
    private boolean isCold;

public	serving_tempreture(String name, double price, char size, boolean isCold) {
	super(name , price , size);
	this.isCold=isCold;
}
	
public boolean isCold() {
return isCold;
}
public void setCold(boolean isCold) {
this.isCold = isCold;
}	
	
public double getPrice(){
	if(name.equals("Juice"))
	return price=price+2;
	else if (name.equals("Pepsi"))
		return price=price+5;
	else if ((name.equals("water")&& isCold))
		return price+=1;
	return price ;}
	
}

    
