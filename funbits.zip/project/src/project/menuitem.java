
package project;

import java.io.Serializable;

public abstract class menuitem implements Serializable{
    protected String name;
	protected double price;
	protected char size;

public menuitem(String name, double price, char size) {
		this.name = name;
		this.price = price;
		this.size = size;
}
public String getName() {
return name;
}

public void setName(String name) {
		this.name = name;
	
}
	
public abstract double getPrice();
		
	
public void setPrice(double price) {
		this.price = price;
	
}
	
public char getSize() {
		return size;
	
}
	
public void setSize(char size) {
		this.size = size;

}

@Override
	public String toString() {
		return "["+name + "|" + size +"   |";
	}
    
}
