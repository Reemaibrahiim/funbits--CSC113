package project;

import java.io.Serializable;

public class order implements Serializable {

    private int id;
    private String customer;
    private int nItem;
    private menuitem itemList[];

    public order(int id, String c) {
        this.id = id;
        this.customer = c;
        itemList = new menuitem[10];
        nItem = 0;
    }

    public order(order o) {
        this.customer = o.customer;
        this.id = o.id;
        itemList = new menuitem[10];
        for (int i = 0; i < o.nItem; i++) {
            this.itemList[i] = o.itemList[i];
            nItem++;
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public boolean addItem(menuitem i) //aggregation
    {
        if (nItem < itemList.length) {
            itemList[nItem++] = i;
            return true;
        } else {
            System.out.println("Number of item should be less than 10");
            return false;
        }
    }

    public double TotalPrice() {
        double total = 0;
        for (int i = 0; i < nItem; i++) {
            total += itemList[i].getPrice();
        }

        return total;

    }

    public String printBill() {
        String bill = "";
        bill += "Order ID:" + id + "\n";
        for (int i = 0; i < nItem; i++) {
            bill += (i + 1) + "#" + itemList[i] + "\n";
        }
        bill += "---------------------------------\n";
        bill += "Total=" + TotalPrice() + "\n";
        bill += "-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-\n";
        return bill;
    }

}
