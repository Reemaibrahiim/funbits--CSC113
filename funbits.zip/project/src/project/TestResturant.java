package project;
import java.util.*;
public class TestResturant {
     static Scanner in = new Scanner(System.in);
	   public static void main(String[] args) {
               
               
               
               FunBits startframe=new FunBits();
               startframe.setVisible(true); 
	   	
/*resturant obj=new resturant("FunBite",300,11);
	   
 menuitem burger = new food("burger",12 , 's',300,1);
 obj.addItem(burger);
 menuitem pizza = new food("pizza",15 , 's',500,1);
 obj.addItem(pizza);	      
 menuitem hotDog = new food("hot dog",10 , 's',300,1);   
 obj.addItem(hotDog);	      
 menuitem pasta = new food("pasta",9 , 's',250,1);	      
 obj.addItem(pasta);	      
 menuitem cornDog = new food("corn dog",13 , 's',600,1);	      
 obj.addItem(cornDog);
	   
 menuitem cola = new serving_tempreture ("cola",3 ,'m',false  );//**
 obj.addItem(cola);
 menuitem pepsi = new serving_tempreture ("pepsi",3 ,'m',true  );//**
obj.addItem(pepsi);
menuitem coffe = new serving_tempreture ("coffe",5 ,'s' ,false );//**
obj.addItem(coffe);
menuitem hotMoca = new serving_tempreture ("Hot Moca",9 ,'s' ,false );//**
 obj.addItem(hotMoca);
 menuitem juice = new serving_tempreture ("orange juice",3 ,'s' ,true );//**
 obj.addItem(juice);				
 
	   			
	   			
	     
 System.out.println("***********welcome to FunBite***********");	
	   
	      
 int ch =0;	
	      
 do {
	         
System.out.println("========================");	
System.out.println("1) Place an Order ");
System.out.println("2) Cancel Order");
System.out.println("3) Check out ");
System.out.println("4) Exit");
System.out.println("========================");	
	         
ch=in.nextInt();
	      		
	         
switch (ch) {
	            case 1 :
System.out.println("enter name and id");
 String name = in.next();
 int id = in.nextInt();	              
 order obj2=new order(id,name);		               
 obj.addOrder(obj2);
	     	              
 obj.ShowMenue();					
	            
//ask how many  item 
	              
System.out.println("How many Item You Want to order?");	              
int n = in.nextInt();		            
//for loop 	              
for (int i=0;i<n;i++){                  	
System.out.println("enter item id");	                  
int itemid=in.nextInt();	                  
obj.addItemToOrder(id,itemid-1);	               
}			
	            		              
break;			
	           
case 2 :
 System.out.println("Enter Id of order");	              
 int Id = in.nextInt();	               
 obj.removeOrder(Id);	               
 break;
	         	            
case 3 :               
System.out.println("Enter Id of order");	               
int id1 = in.nextInt();	               
obj.orderBill(id1);	               
break;
	         	            
case 4:
	            	
System.out.println("would like to check bill of order? Enetr Y/N");	            	
char yn=in.next().charAt(0);	            	
if(yn=='y'|| yn=='Y') {	            		
System.out.println("Enetr ID of order");	            		
int idBill=in.nextInt();		            	
obj.orderBill(idBill);
}
	         	               
System.out.println("******goodybye come back soon******");	               
break; 
	         		
	            
default:	              
System.out.println("wrong choice try again");}
	      	
	      
 }while(ch!=4);*/
	  
	   }
    
    
}
